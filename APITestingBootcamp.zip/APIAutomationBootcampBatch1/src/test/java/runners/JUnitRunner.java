package runners;

import org.junit.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
features 			= "./src/test/resources/features",
//  glue 			= {"com.saucedemo.stepDefinitions", "com.saucedemo.utils"},
glue 				= "stepDefinitions",
plugin 				= {"pretty", "html:target/cucumber-reports-JUnit.html"},
monochrome 			= true
)

public class JUnitRunner {
//	@Test
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}