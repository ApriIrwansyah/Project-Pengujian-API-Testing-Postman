package runners;

import org.junit.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.core.cli.Main;

@RunWith(Cucumber.class)
@CucumberOptions(
	    features 			= "./src/test/resources/features",
        //  glue 			= {"com.saucedemo.stepDefinitions", "com.saucedemo.utils"},
        glue 				= "stepDefinitions",
        plugin 				= {"pretty", "json:target/cucumber-reports/cucumber.json"},
        monochrome 			= true
)
public class TestRunner {
//	@Test
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
}
