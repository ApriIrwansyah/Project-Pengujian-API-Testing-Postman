package stepDefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.cucumber.core.cli.Main;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import org.slf4j.Logger;
import org.json.JSONObject;

import static io.restassured.RestAssured.given;

public class UserApiSteps {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
    	private static final Logger logger = LoggerFactory.getLogger(UserApiSteps.class);
    	private Response response;
    	private RequestSpecification request;
    	private String baseURL;
    	
//    	Contructor
    	public UserApiSteps() {
    		// TODO Auto-generated method stub
    		try {
//    			Untuk membaca file config.properties
    			 Properties properties = new Properties();
    	         FileInputStream fileInput = new FileInputStream("src/test/resources/config.properties");
    	         properties.load(fileInput);
    	         fileInput.close();
    			
//    			Mengambil nilai base_url dari file konfigurasi
    			baseURL = properties.getProperty("base_url");
    			
    			if (baseURL == null || baseURL.isEmpty()) {
                    throw new RuntimeException("Base URL tidak ditemukan di config.properties");
                }
    			
    			logger.info("Base URL loaded: " + baseURL);
    			
    		} catch (IOException e) {
    			logger.error("Gagal memuat file konfigurasi: config.properties", e);
                throw new RuntimeException("Gagal memuat file konfigurasi: config.properties", e);
    		}
    	}
	
		@Given("I send a GET request to {string}")
		public void i_send_a_get_request_to(String url) {
//			request = RestAssured.given();
//		    response = request.get(url);
//		    logger.info("GET Request sent to: " + url);
//	        logger.info("Response: " + response.prettyPrint());
			
//			Menggabungkan baseURL dengan url yang diberikan
			String fullURL = baseURL + url;
			
//			Log URL yang akan diakses
			logger.info("GET Request mengirimkan ke: " + fullURL);
			
//			Mengirim GET Request dan menyimpan response
	        response = RestAssured.given()
	                .log().all() // Log semua detail request
	                .get(fullURL);
			
//			Log semua detail response
			response.then().log().all();
			
//			Log response ke file
			logger.info("Response Status Code : " + response.getStatusCode());
			logger.info("Response Body : " + response.getBody().asString());
			logger.info("Response: " + response.prettyPrint());
		}

		@Then("the response status code should {int}")
		public void the_response_status_code_should(int StatusCode) {
	        Assert.assertEquals(StatusCode, response.getStatusCode());
	        logger.info("Status Code sesuai: " + response.getStatusCode());
		}

		@Then("the response should contain a list of users")
		public void the_response_should_contain_a_list_of_users() {
			JSONObject jsonResponse = new JSONObject(response.getBody().asString());
			Assert.assertTrue(jsonResponse.getJSONArray("data").length() > 0);
			Assert.assertNotNull(response.jsonPath().getList("data"));
	        logger.info("Response berisi data pengguna: " + jsonResponse.getJSONArray("data").toString());
		}

		@Then("the first user's email should be {string}")
		public void the_first_user_s_email_should_be(String Email) {
		    // Write code here that turns the phrase above into concrete actions
//		    throw new io.cucumber.java.PendingException();
			JSONObject jsonResponse = new JSONObject(response.getBody().asString());
	        String actualEmail = jsonResponse.getJSONArray("data").getJSONObject(0).getString("email");
	        Assert.assertEquals(Email, actualEmail);
	        logger.info("First user's email verified: " + actualEmail);
		}

		@Given("I send a POST request to {string} with payload")
		public void i_send_a_post_request_to_with_payload(String url, String payload) {
		    // Write code here that turns the phrase above into concrete actions
//		    throw new io.cucumber.java.PendingException();
	        request = RestAssured.given().header("Content-Type", "application/json").body(payload);
	        response = request.post(url);
	        logger.info("POST Request sent to: " + url);
	        logger.info("Payload: " + payload);
	        logger.info("Response: " + response.prettyPrint());
		}

		@Then("the response status code should be {int}")
		public void the_response_status_code_should_be(int expectedStatusCode) {
	        Assert.assertEquals(expectedStatusCode, response.getStatusCode());
	        logger.info("Status Code: " + response.getStatusCode());
		}

		@Given("I send a PUT request to {string} with payload")
		public void i_send_a_put_request_to_with_payload(String url, String payload) {
	        request = RestAssured.given().header("Content-Type", "application/json").body(payload);
	        response = request.put(url);
	        logger.info("PUT Request sent to: " + url);
	        logger.info("Payload: " + payload);
	        logger.info("Response: " + response.prettyPrint());
		}

		@Given("I send a DELETE request to {string}")
		public void i_send_a_delete_request_to(String url) {
	        request = RestAssured.given();
	        response = request.delete(url);
	        logger.info("DELETE Request sent to: " + url);
	        logger.info("Response status code: " + response.getStatusCode());
		}
		

//	}

}
